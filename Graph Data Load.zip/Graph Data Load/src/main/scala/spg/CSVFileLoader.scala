package spg

import java.io._
import java.lang.reflect.Field
import java.sql.Time
import java.util.Date
import java.util.zip.ZipFile

import au.com.bytecode.opencsv.CSVReader
import org.neo4j.graphdb.Node
import collection.JavaConversions._


case class ColumnToModelMapping(column: String, model: String)

trait CSVFileLoader {


  def sourcePath: File

  def progressInterval: Int = 10000

  var currentLineNumber = 0

  def mapping: List[ColumnToModelMapping]

  def delimiter: Char = '~'

  def csvColumnHeaders: Array[String]

  def showColumnMapping(pw: PrintWriter): Unit = {
    pw.println(s" ======== >> Processing ${sourcePath.getName}")
    pw.println(s"There are ${csvColumnHeaders.size} header columns in each input line")
    pw.println(s"There are ${csvColumnHeaders.size} fields in the field map")

    pw.println()
    pw.println("Field Mapping { ")
    pw.println("   CSV File         -> Node Property ")
    for (f <- mapping) {
      case ColumnToModelMapping(column, model) =>
        pw.println(s"  $column -> $model")
    }
    pw.println("}")
  }

  def openFile(): InputStream =
    if (sourcePath.getName.endsWith(".zip")) {
      val zip = new ZipFile(sourcePath)
      val entry = zip.entries.find(e => e.getName.endsWith(".csv"))
      require(entry.isDefined, s"Could not find a CSV file in Zipfile ${sourcePath.getCanonicalPath}")
      zip.getInputStream(entry.get)
    }
    else
      new FileInputStream(sourcePath)


  def processFile(pw: PrintWriter) {

    val startTime = new Date().getTime

    val fstrm = openFile()

    val reader = new CSVReader(new InputStreamReader(fstrm), delimiter, '\000')

    val header: Array[String] = reader.readNext()


    var line = 1
    Stream.continually(reader.readNext).takeWhile(record => (record ne null) && (record.repr ne null)).foreach {
      record =>
        processRow(line, record)

        //
        // Every "interval" rows, print time and processing stats.
        //
        if (line % progressInterval == 0) {
          val now = new Date().getTime()
          val msSinceStart: Double = now - startTime
          val rate: Double = (msSinceStart / line) * 1000.0
          val rt = Runtime.getRuntime
          pw.print(f"Read $line%10d records. Total Time = ${msSinceStart / 1000.0}%.2f secs. Time per Record = ${rate}%.2f ns.")
          pw.println(f" Memory (free/total) ${rt.freeMemory() / 1000000.0}%.2f/${rt.totalMemory() / 1000000.0}%.2f ")
        }

        line = line + 1
    }

    reader.close()
    line

  }

  /**
   * To be overidden in a subclass
   * @param line
   * @param data
   */
  def processRow(line: Int, data: Array[String]): Unit


  // Well formed values for using in case statements based on type switches.
  val IntClass = classOf[Int]
  val DoubleClass = classOf[Double]
  val StringClass = classOf[String]
  val DateClass = classOf[Date]
  val TimeClass = classOf[Time]
  val BooleanClass = classOf[Boolean]


  def rowToBean(bean: AnyRef, node: Node, fields: IndexedSeq[String], record: Array[String]): Unit = {

    import FieldAccessor._

    for (i <- 0 until fields.size) {

      val fieldName = fields(i)
      val textValue = record(i)

      if (textValue.length != 0) {
        val beanClass = bean.getClass

        var field: Field = null

        try {

          field = beanClass.getDeclaredField(fieldName)
          require(field != null, s"Field not found: bean = ${beanClass.getSimpleName} field = ${fieldName}")

          field.getType match {
            case IntClass =>
              val integer = FieldFormatter.asInteger(textValue)
              node.setProperty(fieldName, integer.get)
              setField(bean, fieldName, textValue)
            case DoubleClass =>
              val dbl = FieldFormatter.asDouble(textValue)
              node.setProperty(fieldName, dbl.get)
              setField(bean, fieldName, textValue)
            case DateClass =>
              val date = FieldFormatter.asDate(textValue)
              node.setProperty(fieldName, date.get.getTime)
              setField(bean, fieldName, textValue)
            case TimeClass =>
              val time = FieldFormatter.asTime(textValue)
              node.setProperty(fieldName, time.get.getTime)
              setField(bean, fieldName, textValue)
            case StringClass =>
              node.setProperty(fieldName, textValue)
              setField(bean, fieldName, textValue)
            case BooleanClass =>
              val bool = FieldFormatter.asBoolean(textValue)
              node.setProperty(fieldName, if (bool.get == true) 1 else 0)
              setField(bean, fieldName, textValue)
            case x =>
              println(s"Unknown Field Type Class = $beanClass Field = $fieldName FieldType = ${x.getSimpleName} value = $textValue")
          }
        } catch {
          case e: Throwable =>
            println(s"Exception for $beanClass field = $fieldName type = ${field.getType.getSimpleName} value ${e.getMessage}")
        }
      }
    }
  }
}
