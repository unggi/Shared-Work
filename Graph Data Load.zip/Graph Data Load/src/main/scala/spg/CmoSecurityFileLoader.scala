package spg

import java.io.File
import java.sql.Time
import java.util.Date

import org.neo4j.graphdb.DynamicLabel

import scala.collection.mutable

/**
 * Created by usoemard on 9/23/2014.
 */
class CmoSecurityFileLoader(path: File) extends CSVFileLoader {

  def sourcePath = path

  override def delimiter: Char = '~'

  override var currentLineNumber: Int = 0

  override def progressInterval: Int = 10000

  val label = DynamicLabel.label("Security")
   //
  // Map Field Names to Model fields
  /
  val map = (
    "ESMP" -> "ESMID",
    "CSP" -> "CUSIP",
    "SecurityType" -> "SecurityType",
    "AnnouncementDate" -> "AnnouncementDate",
    "Description" -> "Description",
    "IsRule144A" -> "IsRule144A",
    "IssueDate" -> "IssueDate",
    "ParValue" -> "ParValue",
    "Series" -> "Series",
    "IssuerName" -> "IssuerName",
    "CollateralType" -> "CollateralType",
    "FirstSettlementDate" -> "FirstSettlementDate",
    "CouponDividendFrequency" -> "CouponDividendFrequency",
    "CouponDividendRate" -> "CouponDividendRate",
    "DatedDate" -> "DatedDate",
    "LastPayDate" -> "LastPayDate",
    "CurrentMaturityDate" -> "CurrentMaturityDate",
    "PrincipalAmountOutstanding" -> "PrincipalAmountOutstanding",
    "FirstCouponDate" -> "FirstCouponDate",
    "TrancheClass" -> "TrancheClass",
    "IOPOFlag" -> "IOPOFlag",
    "MortgageType" -> "MortgageType",
    "DelayDays" -> "DelayDays",
    "OriginalAmountOfPrincipal" -> "OriginalAmountOfPrincipal",
    "CurrentFactor" -> "CurrentFactor",
    "CurrentFactorEffectiveDate" -> "CurrentFactorEffectiveDate",
    "IsMtgePaidOff" -> "IsMtgePaidOff",
    "MtgeCMOGroup" -> "MtgeCMOGroup",
    "IsRegS" -> "IsRegS",
    "BMT" -> "BMT",
    "ISIN" -> "ISIN",
    "dataSource" -> "dataSource",
    "dataTimestamp" -> "dataTimestamp",
    "SEC_ID" -> "SEC_ID",
   "MktSector" -> "MktSector"
  )


  override def processRow(line: Int, data: Array[String]): Unit = {
    println(s"Row $line ${data.size} fields")
  }

}
