package spg;

import org.neo4j.graphdb.RelationshipType;

/**
 * Created by usoemard on 7/14/2014.
 */

enum Relationships implements RelationshipType {
    PRODUCT
}
