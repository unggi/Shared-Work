package spg

import java.io.{PrintWriter, File}

import org.scalatest.{FlatSpec, Matchers}

class TestCmoSecurityFileLoader extends FlatSpec with Matchers {

  val date = "20140721"
  val CMO_SECURITIES = "\\\\spgnasprd.us.nomura.com\\mbsdata$\\mbsdata\\prod\\solr-security-feed\\data\\cmo." + date + ".zip"

  behavior of "Cmo Security File Loader"

    it should "Load a complete file" in {

      val loader = new CmoSecurityFileLoader(new File(CMO_SECURITIES))
      loader.processFile(new PrintWriter(System.out))

    }


}
